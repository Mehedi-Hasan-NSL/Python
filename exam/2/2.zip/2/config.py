from dataclasses import dataclass

@dataclass
class Config:
	VAL_SPLIT = .2
	TRAIN_BATCH_SIZE = 32
	LR = 0.001
	FILTER_SIZE = 32
	KERNEL_SIZE = (3, 3)
config = Config()