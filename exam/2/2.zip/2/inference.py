from data_load import *
from keras.models import load_model

### Loading the model
root_dir = os.path.dirname(os.path.abspath(__file__))
model_name = "autoendcoder_20_epochs.h5"
model_path = os.path.join(root_dir, "models")
model = os.path.join(model_path, model_name)
autoencoder = load_model(model)


### predictions for all the test data and displaying 10 precdictions 
# predictions = autoencoder.predict(test_data)
# display(test_data, predictions)


## input one single image 

## using a single image from mnist
input_image_idx = 100
test_image = test_data[input_image_idx]

# you can use a image from directory 
# test_image_path = '/home/nsl6/abir/ra_evaluation_abir/2/7.JPG'
# test_image = Image.open(test_image_path ).convert('L')  

# #print(test_image.size)
# test_image = test_image.resize((28,28))
# test_image = np.array(test_image)
# test_image = test_image/255

## plotting Input Image
plt.subplot(1, 2, 1)
plt.imshow(test_image.reshape(28,28))
plt.xlabel("Input Image", fontsize=15)
plt.gray()
#plt.show()

## inferencing on test image
test_image = np.expand_dims(test_image, axis=0)
#print(test_image.shape)
prediction = autoencoder.predict(test_image)
#print(prediction.shape)

predict_image = prediction.reshape(28,28)

plt.subplot(1, 2, 2)
plt.imshow(predict_image*255)
plt.xlabel("Predicted Image", fontsize=15)
plt.gray()
plt.show()

## save the output file
#cv2.imwrite(root_dir + "/test.jpg", prediction.reshape(28,28))


