import sys
print(sys.path)
sys.path.append('..')
from ..musicplayer.audio import read_audio


